PluginInit = {
	currentDisplayImage = "no",
	pluginID = "com.adobe.lightroom.sdk.metadata.custommetadatasample",
	URL = "http://www.adobe.com",
}
